<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SB Admin - Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="index.php">Home</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>

 

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Home</span>
        </a>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
<!--
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Overview</li>
        </ol>
-->



        <!-- DataTables Example -->
        <div class="card mb-3">
            
          <div class="card-header">
<!--            <i class="fas fa-table"></i>-->
            <a class="btn btn-primary text-right" href="index.php" role="button"> <i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a>
            </div>
            <!-- Modal -->
            <div class="m-5">

                    <div class="login-form">
                        <!-- logo-login -->
                        <?php
                        if(isset($_POST['register']))
                        {
            				$song_name=(isset($_POST['song_name']))?$_POST['song_name']:"";
                            $do_released=(isset($_POST['do_released']))?$_POST['do_released']:"";
                            $artwork=(isset($_POST['artwork']))?$_POST['artwork']:"";
                            $artist_name=(isset($_POST['artist_name']))?$_POST['artist_name']:"";
            				//---connect to DB---
            				$con=mysqli_connect("localhost","root","","deltax");
            				// insert data into a table
            				mysqli_query($con,"insert into add_songs values('','$song_name','$do_released','$artwork','$artist_name')");
                         
            				echo mysqli_error($con);
            				if(mysqli_affected_rows($con)==1)
            				{
            					echo "<p>Thenks we will get back you soon.</p>";
            				}
            				else
            				{
            					echo"<p>Sorry!! Unable to process try agin.</p>";
            				}

                        }
                    ?>                                                                                                            
                    <?php
                        if(isset($_POST['submit']))
                        {
            				$artist_name=(isset($_POST['artist_name']))?$_POST['artist_name']:"";
                            $dob=(isset($_POST['dob']))?$_POST['dob']:"";
                            $bio=(isset($_POST['bio']))?$_POST['bio']:"";
                            
            				//---connect to DB---
            				$con=mysqli_connect("localhost","root","","deltax");
            				// insert data into a table
            				mysqli_query($con,"insert into add_artist values('','$artist_name','$dob','$bio')");
                         
            				echo mysqli_error($con);
            				if(mysqli_affected_rows($con)==1)
            				{
            					echo "<p>Thenks we will get back you soon.</p>";
            				}
            				else
            				{
            					echo"<p>Sorry!! Unable to process try agin.</p>";
            				}                     
//                            print_r("rajni");
                        }
                    ?> 
                        <h2>Adding a New Song</h2><br>
                       
                    <form method="POST" action="" onsubmit="#"> 
                        <table>
                            <tr>
                                <th><label for="Song Name">Song Name </label></th>
                                <td><input type="text" class="form-control" name="song_name" id="song_name" aria-describedby="emailHelp" placeholder="Song Name"></td>
                            </tr>
                            <tr>
                                <th><label for="Song Name">Date Released </label></th>
                                <td><input type="date" class="form-control" name="do_released" id="do_released" aria-describedby="emailHelp" placeholder="Date Released"></td>
                            </tr>
                            <tr>
                                <th><label for="Artwork"> Artwork</label></th>
                                <td><input type="file" class="form-control-file" name="artwork" id="exampleFormControlFile1"></td>
                            </tr>
                            <tr>
                                <th><label for="Artists"> Artists</label></th>
                                <td><select class="form-control form-control-sm" name="artist_name">
                                      <option>Search</option>
                                      <option>Abhay</option>
                                      <option>Ashutosh</option>
                                      <option>Rajnikant</option>
                                      <option>Irshad</option>
                                    </select>
                                </td>
                                <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                      + Add Artist
                                    </button></td>
                            </tr>
                            <tr>
                            <th></th>
                                <td><div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                            <td><input type="submit" name="register"  value="Save" class="button button2"></td>
                                          </div>
                                </td>
                            </tr>   
                        </table>
                        </form>
                    </div>
            </div>
          <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
        </div>

      </div>
      <!-- /.container-fluid -->       
<!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                      <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Add Artist</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                              <span aria-hidden="true">&times;</span>
                                            </button>
                                          </div>
                                            
                                        <form method="POST" action="" onsubmit="#">
                                          <div class="modal-body">
                                              <table>
                                                <tr>
                                                    <th><label for="Song Name">Artist Name </label></th>
                                                    <td><input type="text" class="form-control" name="artist_name" aria-describedby="emailHelp" placeholder="Artist Name"></td>
                                                </tr>
                                                <tr>
                                                    <th><label for="Song Name">Date of Birth </label></th>
                                                    <td><input type="date" class="form-control" name="dob" id="song_name" aria-describedby="emailHelp" placeholder="Date Released"></td>
                                                </tr>
                                                  <tr>
                                                        <th><label for="Song Name">Bio </label></th>
                                                        <td><textarea class="form-control" name="bio" id="exampleFormControlTextarea1" rows="3"></textarea></td>
                                                  </tr>
                                              </table>

                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                              <!-- <button type="button" class="btn btn-primary" name="submit">Save</button> -->
                                            <input type="submit" name="submit"  value="Save" class="button button2">
                                          </div>
                                        </form>
                                            
                                        </div>
                                      </div>
                                    </div>
                                    <!-- Model end -->
                            
      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Your Website 2020</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="vendor/chart.js/Chart.min.js"></script>
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="js/demo/datatables-demo.js"></script>
  <script src="js/demo/chart-area-demo.js"></script>

</body>

</html>
