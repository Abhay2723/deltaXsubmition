-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2022 at 06:30 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `deltax`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_artist`
--

CREATE TABLE `add_artist` (
  `id` int(10) NOT NULL,
  `artist_name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `bio` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_artist`
--

INSERT INTO `add_artist` (`id`, `artist_name`, `dob`, `bio`) VALUES
(1, '', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `add_songs`
--

CREATE TABLE `add_songs` (
  `id` int(10) NOT NULL,
  `song_name` varchar(50) NOT NULL,
  `do_released` date NOT NULL,
  `artwork` varchar(50) NOT NULL,
  `artist_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_songs`
--

INSERT INTO `add_songs` (`id`, `song_name`, `do_released`, `artwork`, `artist_name`) VALUES
(1, 'do you know', '2022-07-19', 'IMG_20220613_110320.jpg', 'Ashutosh'),
(2, '245 sidu', '2022-07-06', 'asf.png', 'Abhay'),
(3, 'Jaguar', '2022-07-02', 'Switch.png', 'Irshad'),
(4, 'do you know', '2022-07-16', 'IMG_20220613_110320.jpg', 'Ashutosh'),
(5, 'cncn', '2022-07-22', 'betu.jpg', 'Rajnikant');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_artist`
--
ALTER TABLE `add_artist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_songs`
--
ALTER TABLE `add_songs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_artist`
--
ALTER TABLE `add_artist`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `add_songs`
--
ALTER TABLE `add_songs`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
